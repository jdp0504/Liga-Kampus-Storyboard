package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UpdateStandingsServlet", urlPatterns = {"/UpdateStandingsServlet"})
public class UpdateStandingsServlet extends HttpServlet {

    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    private void initTable(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE FOOTBALL_STANDINGS (team_name VARCHAR(100) PRIMARY KEY, played INT DEFAULT 0, wins INT DEFAULT 0, draws INT DEFAULT 0, losses INT DEFAULT 0, goals_for INT DEFAULT 0, goals_against INT DEFAULT 0, goal_diff INT DEFAULT 0, points INT DEFAULT 0)")) {
            ps.execute();
        } catch (SQLException e) { /* already exists */ }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String teamName = request.getParameter("teamName");
        String playedStr = request.getParameter("played");
        String winsStr = request.getParameter("wins");
        String drawsStr = request.getParameter("draws");
        String lossesStr = request.getParameter("losses");
        String gfStr = request.getParameter("goalsFor");
        String gaStr = request.getParameter("goalsAgainst");

        if (teamName == null || teamName.trim().isEmpty()) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        int played = 0, wins = 0, draws = 0, losses = 0, gf = 0, ga = 0;
        try {
            played = Integer.parseInt(playedStr);
            wins = Integer.parseInt(winsStr);
            draws = Integer.parseInt(drawsStr);
            losses = Integer.parseInt(lossesStr);
            gf = Integer.parseInt(gfStr);
            ga = Integer.parseInt(gaStr);
        } catch (NumberFormatException e) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        int gd = gf - ga;
        int points = wins * 3 + draws;

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTable(conn);

            try (PreparedStatement checkPs = conn.prepareStatement("SELECT team_name FROM FOOTBALL_STANDINGS WHERE team_name = ?")) {
                checkPs.setString(1, teamName);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next()) {
                        try (PreparedStatement updatePs = conn.prepareStatement(
                                "UPDATE FOOTBALL_STANDINGS SET played = ?, wins = ?, draws = ?, losses = ?, goals_for = ?, goals_against = ?, goal_diff = ?, points = ? WHERE team_name = ?")) {
                            updatePs.setInt(1, played);
                            updatePs.setInt(2, wins);
                            updatePs.setInt(3, draws);
                            updatePs.setInt(4, losses);
                            updatePs.setInt(5, gf);
                            updatePs.setInt(6, ga);
                            updatePs.setInt(7, gd);
                            updatePs.setInt(8, points);
                            updatePs.setString(9, teamName);
                            updatePs.executeUpdate();
                        }
                    } else {
                        try (PreparedStatement insertPs = conn.prepareStatement(
                                "INSERT INTO FOOTBALL_STANDINGS (team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                            insertPs.setString(1, teamName);
                            insertPs.setInt(2, played);
                            insertPs.setInt(3, wins);
                            insertPs.setInt(4, draws);
                            insertPs.setInt(5, losses);
                            insertPs.setInt(6, gf);
                            insertPs.setInt(7, ga);
                            insertPs.setInt(8, gd);
                            insertPs.setInt(9, points);
                            insertPs.executeUpdate();
                        }
                    }
                }
            }

            response.sendRedirect("admin_dashboard.jsp?status=standings_saved");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String teamName = request.getParameter("teamName");
        if (teamName == null || teamName.trim().isEmpty()) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTable(conn);
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM FOOTBALL_STANDINGS WHERE team_name = ?")) {
                ps.setString(1, teamName);
                ps.executeUpdate();
            }
            response.sendRedirect("admin_dashboard.jsp?status=standings_deleted");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }
}
