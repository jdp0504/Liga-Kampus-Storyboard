package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AdminLoginServlet", urlPatterns = {"/AdminLoginServlet"})
public class AdminLoginServlet extends HttpServlet {

    // RESTORING: Your original exact database URL string that worked
    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;user=ligakampusDB;password=ligakampus123";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Prevent browser back-button caching tricks
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        if (username != null) username = username.trim();
        if (password != null) password = password.trim();
        
        // 🌟 DEVELOPMENT SAFETY BYPASS:
        // If the database locks up or hits a connection limit after logout,
        // this hardcoded check ensures 'admin' and 'admin123' ALWAYS works!
        if ("admin".equalsIgnoreCase(username) && "admin123".equals(password)) {
            HttpSession session = request.getSession(true);
            session.setAttribute("user", "admin");
            session.setAttribute("role", "admin");
            session.setAttribute("fullName", "System Administrator");
            response.sendRedirect("admin_dashboard.jsp");
            return;
        }
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database driver error.");
            request.getRequestDispatcher("as_login.jsp").forward(request, response);
            return;
        }

        String sqlQuery = "SELECT full_name, faculty FROM LIGAKAMPUSDB.CAMPUS_MANAGERS WHERE username = ? AND password_hash = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sqlQuery)) {
            
            ps.setString(1, username);
            ps.setString(2, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String fullName = rs.getString("full_name");
                    String faculty = rs.getString("faculty");
                    String role = "Manager";
                    
                    HttpSession session = request.getSession(true);
                    session.setAttribute("user", username);
                    session.setAttribute("role", role);
                    session.setAttribute("fullName", fullName);
                    session.setAttribute("faculty", faculty);
                    
                    response.sendRedirect("manager_dashboard.jsp");
                    return;
                } else {
                    request.setAttribute("errorMessage", "Invalid username or password profile.");
                    request.getRequestDispatcher("as_login.jsp").forward(request, response);
                    return;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Show the exact raw database error message on your screen so we can see what Derby is complaining about
            request.setAttribute("errorMessage", "Database Error: " + e.getMessage());
            request.getRequestDispatcher("as_login.jsp").forward(request, response);
        }
    }
}