package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "AthleteServlet", urlPatterns = {"/AthleteServlet"})
public class AthleteServlet extends HttpServlet {

    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    private void initTable(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE ATHLETES (athlete_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), student_id VARCHAR(20) NOT NULL, full_name VARCHAR(200) NOT NULL, team_name VARCHAR(100) NOT NULL, sport_category VARCHAR(50) NOT NULL, event_category VARCHAR(50), jersey_number INT, position VARCHAR(50), PRIMARY KEY (athlete_id))")) {
            ps.execute();
        } catch (SQLException e) { /* table already exists */ }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String athleteId = request.getParameter("athleteId");
        String studentId = request.getParameter("studentId");
        String fullName = request.getParameter("fullName");
        String teamName = request.getParameter("teamName");
        String jerseyNumStr = request.getParameter("jerseyNum");
        String position = request.getParameter("position");

        if (studentId == null || studentId.trim().isEmpty()
                || fullName == null || fullName.trim().isEmpty()
                || teamName == null || teamName.trim().isEmpty()) {
            response.sendRedirect("manager_dashboard.jsp?status=invalid_input");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("manager_dashboard.jsp?status=driver_error");
            return;
        }

        Integer jerseyNum = null;
        if (jerseyNumStr != null && !jerseyNumStr.trim().isEmpty()) {
            try {
                jerseyNum = Integer.parseInt(jerseyNumStr.trim());
            } catch (NumberFormatException e) { /* ignore */ }
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTable(conn);

            if (athleteId != null && !athleteId.trim().isEmpty()) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE ATHLETES SET student_id = ?, full_name = ?, team_name = ?, sport_category = 'Football', event_category = 'Football Open', jersey_number = ?, position = ? WHERE athlete_id = ?")) {
                    ps.setString(1, studentId.trim());
                    ps.setString(2, fullName.trim());
                    ps.setString(3, teamName.trim());
                    if (jerseyNum != null) ps.setInt(4, jerseyNum);
                    else ps.setNull(4, java.sql.Types.INTEGER);
                    ps.setString(5, position != null ? position.trim() : null);
                    ps.setInt(6, Integer.parseInt(athleteId.trim()));
                    ps.executeUpdate();
                }
            } else {
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO ATHLETES (student_id, full_name, team_name, sport_category, event_category, jersey_number, position) VALUES (?, ?, ?, 'Football', 'Football Open', ?, ?)")) {
                    ps.setString(1, studentId.trim());
                    ps.setString(2, fullName.trim());
                    ps.setString(3, teamName.trim());
                    if (jerseyNum != null) ps.setInt(4, jerseyNum);
                    else ps.setNull(4, java.sql.Types.INTEGER);
                    ps.setString(5, position != null ? position.trim() : null);
                    ps.executeUpdate();
                }
            }

            response.sendRedirect("manager_dashboard.jsp?status=athlete_saved");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("manager_dashboard.jsp?status=db_error");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String deleteId = request.getParameter("delete");
        if (deleteId == null || deleteId.trim().isEmpty()) {
            response.sendRedirect("manager_dashboard.jsp");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("manager_dashboard.jsp?status=driver_error");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTable(conn);

            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM ATHLETES WHERE athlete_id = ?")) {
                ps.setInt(1, Integer.parseInt(deleteId.trim()));
                ps.executeUpdate();
            }

            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM MATCH_GOALSCORERS WHERE athlete_id = ?")) {
                ps.setInt(1, Integer.parseInt(deleteId.trim()));
                ps.executeUpdate();
            }

            try (Statement stmt = conn.createStatement()) {
                stmt.execute("DELETE FROM FOOTBALL_TOP_SCORERS");
            }
            try (PreparedStatement aggPs = conn.prepareStatement(
                    "INSERT INTO FOOTBALL_TOP_SCORERS (player_name, team_name, goals) SELECT athlete_name, team_name, SUM(goals) FROM MATCH_GOALSCORERS GROUP BY athlete_name, team_name ORDER BY SUM(goals) DESC")) {
                aggPs.executeUpdate();
            }

            conn.createStatement().execute("DELETE FROM FOOTBALL_STANDINGS");
            try (Statement s = conn.createStatement();
                 ResultSet teamsRs = s.executeQuery("SELECT team_name FROM TEAMS")) {
                while (teamsRs.next()) {
                    String team = teamsRs.getString("team_name");
                    int played = 0, wins = 0, draws = 0, losses = 0;
                    int gf = 0, ga = 0;
                    try (PreparedStatement mp = conn.prepareStatement(
                            "SELECT match_id, team1_score, team2_score, team1, team2 FROM FOOTBALL_MATCHES WHERE status = 'Completed' AND (team1 = ? OR team2 = ?) AND team1_score IS NOT NULL AND team2_score IS NOT NULL")) {
                        mp.setString(1, team);
                        mp.setString(2, team);
                        try (ResultSet mr = mp.executeQuery()) {
                            while (mr.next()) {
                                int matchId = mr.getInt("match_id");
                                int s1 = mr.getInt("team1_score");
                                int s2 = mr.getInt("team2_score");
                                String t1 = mr.getString("team1");
                                String t2 = mr.getString("team2");
                                played++;
                                if (t1.equals(team)) {
                                    ga += s2;
                                    if (s1 > s2) wins++;
                                    else if (s1 < s2) losses++;
                                    else draws++;
                                } else {
                                    ga += s1;
                                    if (s2 > s1) wins++;
                                    else if (s2 < s1) losses++;
                                    else draws++;
                                }
                                try (PreparedStatement gsp = conn.prepareStatement(
                                        "SELECT COALESCE(SUM(goals), 0) FROM MATCH_GOALSCORERS WHERE match_id = ? AND team_name = ?")) {
                                    gsp.setInt(1, matchId);
                                    gsp.setString(2, team);
                                    try (ResultSet gsr = gsp.executeQuery()) {
                                        if (gsr.next()) gf += gsr.getInt(1);
                                    }
                                }
                            }
                        }
                    }
                    int gd = gf - ga;
                    int points = wins * 3 + draws;
                    try (PreparedStatement up = conn.prepareStatement(
                            "INSERT INTO FOOTBALL_STANDINGS (team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                        up.setString(1, team);
                        up.setInt(2, played);
                        up.setInt(3, wins);
                        up.setInt(4, draws);
                        up.setInt(5, losses);
                        up.setInt(6, gf);
                        up.setInt(7, ga);
                        up.setInt(8, gd);
                        up.setInt(9, points);
                        up.executeUpdate();
                    }
                }
            }

            response.sendRedirect("manager_dashboard.jsp?status=athlete_deleted");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("manager_dashboard.jsp?status=db_error");
        }
    }
}
