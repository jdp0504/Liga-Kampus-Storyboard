package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ScheduleMatchServlet", urlPatterns = {"/ScheduleMatchServlet"})
public class ScheduleMatchServlet extends HttpServlet {

    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    private void initTables(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE FOOTBALL_MATCHES (match_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), stage VARCHAR(100), team1 VARCHAR(100), team2 VARCHAR(100), team1_score INT, team2_score INT, match_date VARCHAR(50), venue VARCHAR(200), status VARCHAR(20))")) {
            ps.execute();
        } catch (SQLException e) { /* already exists */ }
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE FOOTBALL_STANDINGS (team_name VARCHAR(100) PRIMARY KEY, played INT DEFAULT 0, wins INT DEFAULT 0, draws INT DEFAULT 0, losses INT DEFAULT 0, goals_for INT DEFAULT 0, goals_against INT DEFAULT 0, goal_diff INT DEFAULT 0, points INT DEFAULT 0)")) {
            ps.execute();
        } catch (SQLException e) { /* already exists */ }
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE MATCH_GOALSCORERS (goal_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), match_id INT NOT NULL, team_name VARCHAR(100) NOT NULL, athlete_id INT, athlete_name VARCHAR(200) NOT NULL, goals INT DEFAULT 1, PRIMARY KEY (goal_id))")) {
            ps.execute();
        } catch (SQLException e) { /* already exists */ }
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE FOOTBALL_TOP_SCORERS (scorer_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), player_name VARCHAR(200), team_name VARCHAR(100), goals INT DEFAULT 0)")) {
            ps.execute();
        } catch (SQLException e) { /* already exists */ }
    }

    private void recalculateAllStandings(Connection conn) {
        try {
            conn.createStatement().execute("DELETE FROM FOOTBALL_STANDINGS");

            try (Statement stmt = conn.createStatement();
                 ResultSet teamsRs = stmt.executeQuery("SELECT team_name FROM TEAMS")) {

                while (teamsRs.next()) {
                    String team = teamsRs.getString("team_name");
                    int played = 0, wins = 0, draws = 0, losses = 0;
                    int gf = 0, ga = 0;

                    try (PreparedStatement matchPs = conn.prepareStatement(
                            "SELECT match_id, team1_score, team2_score, team1, team2 FROM FOOTBALL_MATCHES WHERE status = 'Completed' AND (team1 = ? OR team2 = ?) AND team1_score IS NOT NULL AND team2_score IS NOT NULL")) {
                        matchPs.setString(1, team);
                        matchPs.setString(2, team);
                        try (ResultSet matchRs = matchPs.executeQuery()) {
                            while (matchRs.next()) {
                                int matchId = matchRs.getInt("match_id");
                                int s1 = matchRs.getInt("team1_score");
                                int s2 = matchRs.getInt("team2_score");
                                String t1 = matchRs.getString("team1");
                                String t2 = matchRs.getString("team2");

                                played++;
                                // goals_against from match score (opponent's goals)
                                if (t1.equals(team)) {
                                    ga += s2;
                                    if (s1 > s2) wins++;
                                    else if (s1 < s2) losses++;
                                    else draws++;
                                } else {
                                    ga += s1;
                                    if (s2 > s1) wins++;
                                    else if (s2 < s1) losses++;
                                    else draws++;
                                }
                                // goals_for from MATCH_GOALSCORERS (actual player goals)
                                try (PreparedStatement gsPs = conn.prepareStatement(
                                        "SELECT COALESCE(SUM(goals), 0) FROM MATCH_GOALSCORERS WHERE match_id = ? AND team_name = ?")) {
                                    gsPs.setInt(1, matchId);
                                    gsPs.setString(2, team);
                                    try (ResultSet gsRs = gsPs.executeQuery()) {
                                        if (gsRs.next()) {
                                            gf += gsRs.getInt(1);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    int gd = gf - ga;
                    int points = wins * 3 + draws;

                    try (PreparedStatement upsertPs = conn.prepareStatement(
                            "INSERT INTO FOOTBALL_STANDINGS (team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                        upsertPs.setString(1, team);
                        upsertPs.setInt(2, played);
                        upsertPs.setInt(3, wins);
                        upsertPs.setInt(4, draws);
                        upsertPs.setInt(5, losses);
                        upsertPs.setInt(6, gf);
                        upsertPs.setInt(7, ga);
                        upsertPs.setInt(8, gd);
                        upsertPs.setInt(9, points);
                        upsertPs.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String matchId = request.getParameter("matchId");
        String stage = request.getParameter("stageMeta");
        String team1 = request.getParameter("team1Select");
        String team2 = request.getParameter("team2Select");
        String t1ScoreStr = request.getParameter("team1Score");
        String t2ScoreStr = request.getParameter("team2Score");
        String matchDate = request.getParameter("matchDate");
        String venue = request.getParameter("venue");
        String status = request.getParameter("statusSelect");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTables(conn);

            if (matchId != null && !matchId.trim().isEmpty()) {
                String sql = "UPDATE FOOTBALL_MATCHES SET stage=?, team1=?, team2=?, team1_score=?, team2_score=?, match_date=?, venue=?, status=? WHERE match_id=?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, stage);
                    ps.setString(2, team1);
                    ps.setString(3, team2);

                    if (t1ScoreStr != null && !t1ScoreStr.trim().isEmpty()) {
                        ps.setInt(4, Integer.parseInt(t1ScoreStr.trim()));
                    } else {
                        ps.setNull(4, java.sql.Types.INTEGER);
                    }

                    if (t2ScoreStr != null && !t2ScoreStr.trim().isEmpty()) {
                        ps.setInt(5, Integer.parseInt(t2ScoreStr.trim()));
                    } else {
                        ps.setNull(5, java.sql.Types.INTEGER);
                    }

                    ps.setString(6, matchDate);
                    ps.setString(7, venue);
                    ps.setString(8, status);
                    ps.setInt(9, Integer.parseInt(matchId.trim()));
                    ps.executeUpdate();
                }
            } else {
                String sql = "INSERT INTO FOOTBALL_MATCHES (stage, team1, team2, team1_score, team2_score, match_date, venue, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, stage);
                    ps.setString(2, team1);
                    ps.setString(3, team2);

                    if (t1ScoreStr != null && !t1ScoreStr.trim().isEmpty()) {
                        ps.setInt(4, Integer.parseInt(t1ScoreStr.trim()));
                    } else {
                        ps.setNull(4, java.sql.Types.INTEGER);
                    }

                    if (t2ScoreStr != null && !t2ScoreStr.trim().isEmpty()) {
                        ps.setInt(5, Integer.parseInt(t2ScoreStr.trim()));
                    } else {
                        ps.setNull(5, java.sql.Types.INTEGER);
                    }

                    ps.setString(6, matchDate);
                    ps.setString(7, venue);
                    ps.setString(8, status);
                    ps.executeUpdate();
                }
            }

            String[] gsTeams = request.getParameterValues("gs_team");
            String[] gsPlayers = request.getParameterValues("gs_player");
            String[] gsPlayerNames = request.getParameterValues("gs_player_name");
            String[] gsGoalsStrs = request.getParameterValues("gs_goals");

            if (matchId != null && gsTeams != null && gsPlayers != null && gsPlayerNames != null && gsGoalsStrs != null) {
                int mid = Integer.parseInt(matchId.trim());
                try (PreparedStatement delPs = conn.prepareStatement("DELETE FROM MATCH_GOALSCORERS WHERE match_id = ?")) {
                    delPs.setInt(1, mid);
                    delPs.executeUpdate();
                }
                try (PreparedStatement insPs = conn.prepareStatement(
                        "INSERT INTO MATCH_GOALSCORERS (match_id, team_name, athlete_id, athlete_name, goals) VALUES (?, ?, ?, ?, ?)")) {
                    for (int i = 0; i < gsTeams.length; i++) {
                        int g;
                        try { g = Integer.parseInt(gsGoalsStrs[i].trim()); } catch (NumberFormatException e) { continue; }
                        if (g <= 0) continue;
                        insPs.setInt(1, mid);
                        insPs.setString(2, gsTeams[i]);
                        if (gsPlayers[i] != null && !gsPlayers[i].isEmpty()) {
                            try { insPs.setInt(3, Integer.parseInt(gsPlayers[i].trim())); }
                            catch (NumberFormatException e) { insPs.setNull(3, java.sql.Types.INTEGER); }
                        } else {
                            insPs.setNull(3, java.sql.Types.INTEGER);
                        }
                        insPs.setString(4, gsPlayerNames[i]);
                        insPs.setInt(5, g);
                        insPs.executeUpdate();
                    }
                }
                try (Statement recalcPs = conn.createStatement()) {
                    recalcPs.execute("DELETE FROM FOOTBALL_TOP_SCORERS");
                }
                try (PreparedStatement aggPs = conn.prepareStatement(
                        "INSERT INTO FOOTBALL_TOP_SCORERS (player_name, team_name, goals) SELECT athlete_name, team_name, SUM(goals) FROM MATCH_GOALSCORERS GROUP BY athlete_name, team_name ORDER BY SUM(goals) DESC")) {
                    aggPs.executeUpdate();
                }

                try (PreparedStatement scorePs = conn.prepareStatement(
                        "UPDATE FOOTBALL_MATCHES SET team1_score = (SELECT COALESCE(SUM(goals), 0) FROM MATCH_GOALSCORERS WHERE match_id = ? AND team_name = ?), team2_score = (SELECT COALESCE(SUM(goals), 0) FROM MATCH_GOALSCORERS WHERE match_id = ? AND team_name = ?) WHERE match_id = ?")) {
                    scorePs.setInt(1, mid);
                    scorePs.setString(2, team1);
                    scorePs.setInt(3, mid);
                    scorePs.setString(4, team2);
                    scorePs.setInt(5, mid);
                    scorePs.executeUpdate();
                }
            }

            recalculateAllStandings(conn);

            response.sendRedirect("admin_dashboard.jsp");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }
}
