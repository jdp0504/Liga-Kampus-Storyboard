package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "TeamServlet", urlPatterns = {"/TeamServlet"})
public class TeamServlet extends HttpServlet {

    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    private void initTables(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE TEAMS (team_name VARCHAR(100) PRIMARY KEY, faculty_code VARCHAR(10))")) {
            ps.execute();
        } catch (SQLException e) { /* table already exists */ }
        try (PreparedStatement ps = conn.prepareStatement(
                "ALTER TABLE TEAMS ADD COLUMN faculty_code VARCHAR(10)")) {
            ps.execute();
        } catch (SQLException e) { /* column already exists */ }
        try (PreparedStatement ps = conn.prepareStatement(
                "CREATE TABLE FOOTBALL_STANDINGS (team_name VARCHAR(100) PRIMARY KEY, played INT DEFAULT 0, wins INT DEFAULT 0, draws INT DEFAULT 0, losses INT DEFAULT 0, goals_for INT DEFAULT 0, goals_against INT DEFAULT 0, goal_diff INT DEFAULT 0, points INT DEFAULT 0)")) {
            ps.execute();
        } catch (SQLException e) { /* table already exists */ }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String teamName = request.getParameter("teamName");
        String facultyCode = request.getParameter("facultyCode");

        if (teamName == null || teamName.trim().isEmpty()) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTables(conn);

            try {
                try (PreparedStatement insertPs = conn.prepareStatement("INSERT INTO TEAMS (team_name, faculty_code) VALUES (?, ?)")) {
                    insertPs.setString(1, teamName);
                    insertPs.setString(2, facultyCode);
                    insertPs.executeUpdate();
                }
            } catch (SQLException e) {
                try (PreparedStatement updatePs = conn.prepareStatement("UPDATE TEAMS SET faculty_code = ? WHERE team_name = ?")) {
                    updatePs.setString(1, facultyCode);
                    updatePs.setString(2, teamName);
                    updatePs.executeUpdate();
                }
            }
            try {
                try (PreparedStatement fsPs = conn.prepareStatement(
                        "INSERT INTO FOOTBALL_STANDINGS (team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0)")) {
                    fsPs.setString(1, teamName);
                    fsPs.executeUpdate();
                }
            } catch (SQLException e) { /* row already exists */ }
            response.sendRedirect("admin_dashboard.jsp?status=team_saved");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String teamName = request.getParameter("teamName");
        if (teamName == null || teamName.trim().isEmpty()) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            initTables(conn);
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM TEAMS WHERE team_name = ?")) {
                ps.setString(1, teamName);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM FOOTBALL_STANDINGS WHERE team_name = ?")) {
                ps.setString(1, teamName);
                ps.executeUpdate();
            }
            response.sendRedirect("admin_dashboard.jsp?status=team_deleted");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }
}
