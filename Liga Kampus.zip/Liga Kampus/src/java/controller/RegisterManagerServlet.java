package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegisterManagerServlet", urlPatterns = {"/RegisterManagerServlet"})
public class RegisterManagerServlet extends HttpServlet {

    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
    private final String DB_USER = "ligakampusDB";
    private final String DB_PASSWORD = "ligakampus123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String faculty = request.getParameter("faculty");
        String fullName = request.getParameter("fullName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate all fields are present
        if (faculty == null || faculty.trim().isEmpty()
                || fullName == null || fullName.trim().isEmpty()
                || username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {
            response.sendRedirect("admin_dashboard.jsp?status=invalid_input");
            return;
        }

        faculty = faculty.trim();
        fullName = fullName.trim();
        username = username.trim();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=driver_error");
            return;
        }

        // CHANGE THIS LINE inside RegisterManagerServlet.java
       String sql = "INSERT INTO CAMPUS_MANAGERS (username, password_hash, full_name, faculty) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, fullName);
            ps.setString(4, faculty);
            // Remove any line setting a 5th parameter for role!

            ps.executeUpdate();
            response.sendRedirect("admin_dashboard.jsp?status=registration_success");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("admin_dashboard.jsp?status=db_error");
        }
    }
}