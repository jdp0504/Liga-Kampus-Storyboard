package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {

    // Database configurations matching your local installation properties 
    // Replace your old MySQL variables with these:
    private final String DB_URL = "jdbc:derby://localhost:1527/ligakampusDB;create=true"; 
    private final String DB_USER = "ligakampusDB";     // Or whatever username you chose
    private final String DB_PASSWORD = "ligakampus123"; // Or whatever password you chose

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Collect parameter attributes from registration data submission streams
        String fullName = request.getParameter("fullName");
        String username = request.getParameter("username");
        String faculty = request.getParameter("faculty");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // 2. Structural safety checks validation processing loop
        if (fullName == null || username == null || faculty == null || password == null ||
            fullName.trim().isEmpty() || username.trim().isEmpty() || password.isEmpty()) {
            request.setAttribute("errorMessage", "All registration input profile slots are strictly required.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "Password confirmation profiles do not align.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        username = username.trim();

        // Load Driver Class
        // Load Driver Class 
        try {
             // This is the correct driver class name for Java DB / Apache Derby
             Class.forName("org.apache.derby.jdbc.ClientDriver"); 
        } catch (ClassNotFoundException e) {
             request.setAttribute("errorMessage", "System driver initialization issue: " + e.getMessage());
             request.getRequestDispatcher("register.jsp").forward(request, response);
             return;
        }

        // 3. Database operations process layer
        String checkUserSql = "SELECT user_id FROM Users WHERE username = ?";
        String insertUserSql = "INSERT INTO Users (username, password, email, role) VALUES (?, ?, ?, 'user')";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            
            // Check if user already exists
            try (PreparedStatement checkPs = conn.prepareStatement(checkUserSql)) {
                checkPs.setString(1, username);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next()) {
                        request.setAttribute("errorMessage", "The username / Student ID provided is already in use.");
                        request.getRequestDispatcher("register.jsp").forward(request, response);
                        return;
                    }
                }
            }

            // Insert new user if unique checks pass successfully 
            try (PreparedStatement insertPs = conn.prepareStatement(insertUserSql)) {
                insertPs.setString(1, username);
                insertPs.setString(2, password);
                insertPs.setString(3, username + "@student.uitm.edu.my"); // Standard dummy email constructor generation fallback
                
                int rowsAffected = insertPs.executeUpdate();
                if (rowsAffected > 0) {
                    // Pass a query parameter or session attribute to login page informing of registration success
                    request.setAttribute("successMessage", "Account successfully set up! You are now eligible to authenticate into the application space.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorMessage", "Registration could not be processed due to a system transaction fault.");
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database storage connection failure encountered: " + e.getMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
}