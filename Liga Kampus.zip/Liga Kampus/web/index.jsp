<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liga-Kampus | Football League</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero-section { background: #2d2d2d; color: white; padding: 40px 0; }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

    <nav class="navbar navbar-expand-lg navbar-dark" style="background: purple;">
        <div class="container">
            <a class="navbar-brand" href="index.jsp"><img src="img/logo.png" alt="Liga Kampus" height="60"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                
                </ul>
                <div class="d-flex align-items-center gap-2">
                    <a href="login.jsp" class="btn btn-sm btn-danger fw-bold">Logout</a>
                    <a href="as_login.jsp" class="btn btn-sm btn-light fw-bold">Admin/Manager Access</a>
                </div>
            </div>
        </div>
    </nav>

    <header class="hero-section text-center shadow-sm">
        <div class="container">
            <h1 class="display-5 fw-bold">UITM FOOTBALL LEAGUE</h1>
        </div>
    </header>

    <%
        String dbUrl = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
        String dbUser = "ligakampusDB";
        String dbPass = "ligakampus123";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
    %>

    <main class="container my-5 flex-grow-1">
        <div class="row g-4">

            <section class="col-lg-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h2 class="h5 mb-0 fw-bold" style="color: purple;">League Table</h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 text-center">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 5%">#</th>
                                    <th class="text-start" style="width: 30%">Team</th>
                                    <th>P</th><th>W</th><th>D</th><th>L</th>
                                    <th>GF</th><th>GA</th><th>GD</th>
                                    <th class="fw-bold">PTS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <%
                                    boolean standingsLoaded = false;
                                    try {
                                        Class.forName("org.apache.derby.jdbc.ClientDriver");
                                        conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                                        stmt = conn.createStatement();
                                        rs = stmt.executeQuery("SELECT * FROM FOOTBALL_STANDINGS ORDER BY points DESC, goal_diff DESC, goals_for DESC");
                                        int rank = 0;
                                        while (rs.next()) {
                                            rank++;
                                            standingsLoaded = true;
                                %>
                                    <tr>
                                        <td class="fw-bold"><%= rank %></td>
                                        <td class="text-start fw-bold"><%= rs.getString("team_name") %></td>
                                        <td><%= rs.getInt("played") %></td>
                                        <td><%= rs.getInt("wins") %></td>
                                        <td><%= rs.getInt("draws") %></td>
                                        <td><%= rs.getInt("losses") %></td>
                                        <td><%= rs.getInt("goals_for") %></td>
                                        <td><%= rs.getInt("goals_against") %></td>
                                        <td class="fw-bold"><%= rs.getInt("goal_diff") %></td>
                                        <td class="fw-bold text-primary"><%= rs.getInt("points") %></td>
                                    </tr>
                                <%
                                        }
                                        rs.close();
                                    } catch (Exception e) { /* table may not exist */ }
                                    if (!standingsLoaded) {
                                %>
                                <tr>
                                    <td colspan="10" class="text-muted py-4">No league data yet. Check back after matches are played.</td>
                                </tr>
                                <% } %>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <aside class="col-lg-4" id="schedule-section">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h3 class="h6 mb-0 fw-bold" style="color: purple;">Match Schedules</h3>
                    </div>
                    <div class="list-group list-group-flush">
                        <%
                            boolean matchesLoaded = false;
                            try {
                                if (conn != null && !conn.isClosed()) {
                                    rs = stmt.executeQuery("SELECT stage, team1, team2, team1_score, team2_score, match_date, venue, status FROM FOOTBALL_MATCHES ORDER BY match_id DESC");
                                    while (rs.next()) {
                                        matchesLoaded = true;
                                        String stg = rs.getString("stage");
                                        String t1 = rs.getString("team1");
                                        String t2 = rs.getString("team2");
                                        String st = rs.getString("status");
                                %>
                                <div class="list-group-item py-3">
                                    <div class="d-flex justify-content-between small text-muted mb-1">
                                        <span><%= stg %></span>
                                        <span class="fw-semibold"><%= st %></span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-semibold"><%= t1 %></span>
                                        <%
                                            int sc1 = rs.getInt("team1_score");
                                            boolean nullScore = rs.wasNull();
                                            int sc2 = rs.getInt("team2_score");
                                        %>
                                        <span class="badge <%= nullScore ? "bg-dark" : "bg-primary" %> px-3 py-2"><%= nullScore ? "vs" : (sc1 + " - " + sc2) %></span>
                                        <span class="fw-semibold"><%= t2 %></span>
                                    </div>
                                </div>
                                <%
                                    }
                                    rs.close();
                                }
                            } catch (Exception e) { /* table may not exist */ }
                            if (!matchesLoaded) {
                        %>
                        <div class="list-group-item text-muted small py-4">No matches scheduled yet.</div>
                        <% } %>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3">
                        <h3 class="h6 mb-0 fw-bold" style="color: purple;">Top Scorers</h3>
                    </div>
                    <div class="list-group list-group-flush">
                        <%
                            Connection tsConn = null;
                            Statement tsStmt = null;
                            ResultSet tsRs = null;
                            boolean tsLoaded = false;
                            try {
                                Class.forName("org.apache.derby.jdbc.ClientDriver");
                                tsConn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                                tsStmt = tsConn.createStatement();
                                tsRs = tsStmt.executeQuery("SELECT * FROM FOOTBALL_TOP_SCORERS ORDER BY goals DESC");
                                int tsRank = 0;
                                while (tsRs.next()) {
                                    tsRank++;
                                    tsLoaded = true;
                                    String tsName = tsRs.getString("player_name");
                                    String tsTeam = tsRs.getString("team_name");
                                    int tsGoals = tsRs.getInt("goals");
                        %>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-bold me-2"><%= tsRank %>.</span> <%= tsName %> <small class="text-muted">(<%= tsTeam %>)</small>
                                </div>
                                <span class="fw-bold" style="color: #000;"><%= tsGoals %> Goals</span>
                            </div>
                        <%
                                }
                                tsRs.close(); tsStmt.close(); tsConn.close();
                            } catch (Exception e) { /* table may not exist */ }
                            finally {
                                if (tsRs != null) try { tsRs.close(); } catch (SQLException e) {}
                                if (tsStmt != null) try { tsStmt.close(); } catch (SQLException e) {}
                                if (tsConn != null) try { tsConn.close(); } catch (SQLException e) {}
                            }
                            if (!tsLoaded) {
                        %>
                            <div class="list-group-item text-muted small">No top scorers recorded yet.</div>
                        <% } %>
                    </div>
                </div>
            </aside>
        </div>

    </main>

    <footer class="bg-dark text-white text-center py-4 mt-auto"></footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
