<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, java.util.List" %>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("as_login.jsp");
        return;
    }
    String role = (String) session.getAttribute("role");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liga-Kampus | Football League Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; }
        .card { border: none; border-radius: 15px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        .card-header { border-radius: 15px 15px 0 0 !important; }
        .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; }
        .btn-danger, .btn-danger:hover, .btn-danger:active, .btn-danger:focus { background: #dc3545; border-color: #dc3545; box-shadow: none; }
        .btn-submit { background: #2d2d2d; border: none; color: white; }
        .btn-submit:hover, .btn-submit:active, .btn-submit:focus { background: #2d2d2d; border: none; color: white; box-shadow: none; }
        .spinner-overlay { display: none; position: absolute; inset: 0; align-items: center; justify-content: center; background: inherit; border-radius: inherit; }
        .btn-submit.loading .spinner-overlay { display: flex; }
        .btn-submit.loading .btn-text { visibility: hidden; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark" style="background: purple;">
        <div class="container">
            <a class="navbar-brand" href="admin_dashboard.jsp"><img src="img/logo.png" alt="UiTM Football League" height="60"></a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto"></ul>
                <div class="navbar-nav align-items-center gap-2">
                    <span class="nav-link text-light">
                        <%= session.getAttribute("user") %>
                        <% if (role != null) { %>
                            <span class="badge bg-light text-dark ms-1"><%= role %></span>
                        <% } %>
                    </span>
                    <a href="logout.jsp" class="btn btn-sm btn-danger fw-bold">
                        <i class="fa-solid fa-right-from-bracket me-1"></i> Log Out
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <main class="container my-5">

        <%-- Status alerts from servlet redirects --%>
        <%
            String status = request.getParameter("status");
            if (status != null) {
                if (status.equals("registration_success")) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Operation completed successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("db_error")) {
        %>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-xmark me-1"></i>
                <strong>Database Error!</strong> The operation could not be completed. The record may already exist.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("driver_error") || status.equals("invalid_input")) {
        %>
            <div class="alert alert-warning alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-1"></i>
                <strong>System Error!</strong> Invalid input or configuration issue.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("standings_saved")) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Standings entry saved.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("standings_deleted")) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Standings entry deleted.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("team_saved")) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Team saved.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if (status.equals("team_deleted")) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Team deleted.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                }
            }
        %>

        <%-- Shared DB connection + data fetch --%>
        <%
            String dbUrl = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
            String dbUser = "ligakampusDB";
            String dbPass = "ligakampus123";
            Connection conn = null;
            Statement stmt = null;
            ResultSet rs = null;
            int matchCount = 0;

            // Teams list for dropdowns
            java.util.List<String[]> teams = new java.util.ArrayList<String[]>();
            // Standings data
            java.util.List<String[]> standings = new java.util.ArrayList<String[]>();
            // Top scorers data
            java.util.List<String[]> tsList = new java.util.ArrayList<String[]>();
            // Goalscorers data (for Edit Match)
            java.util.Map<String, java.util.List<String[]>> athletesByTeam = new java.util.HashMap<String, java.util.List<String[]>>();
            java.util.Map<Integer, Integer> matchGoalscorers = new java.util.HashMap<Integer, Integer>();
            String gsMatchId = null;
            String gsTeam1 = null;
            String gsTeam2 = null;
            String gsDebug = "";
            java.util.Map<String, java.util.List<String[]>> athletesByMatchTeam = new java.util.HashMap<String, java.util.List<String[]>>();

            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                stmt = conn.createStatement();

                // Init tables
                try { stmt.execute("CREATE TABLE TEAMS (team_name VARCHAR(100) PRIMARY KEY, faculty_code VARCHAR(10))"); } catch (Exception e) {}
                try { stmt.execute("CREATE TABLE FOOTBALL_MATCHES (match_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), stage VARCHAR(100), team1 VARCHAR(100), team2 VARCHAR(100), team1_score INT, team2_score INT, match_date VARCHAR(50), venue VARCHAR(200), status VARCHAR(20))"); } catch (Exception e) {}
                try { stmt.execute("CREATE TABLE FOOTBALL_STANDINGS (team_name VARCHAR(100) PRIMARY KEY, played INT DEFAULT 0, wins INT DEFAULT 0, draws INT DEFAULT 0, losses INT DEFAULT 0, goals_for INT DEFAULT 0, goals_against INT DEFAULT 0, goal_diff INT DEFAULT 0, points INT DEFAULT 0)"); } catch (Exception e) {}
                try { stmt.execute("CREATE TABLE FOOTBALL_TOP_SCORERS (scorer_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), player_name VARCHAR(200), team_name VARCHAR(100), goals INT DEFAULT 0)"); } catch (Exception e) {}
                try { stmt.execute("CREATE TABLE MATCH_GOALSCORERS (goal_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), match_id INT NOT NULL, team_name VARCHAR(100) NOT NULL, athlete_id INT, athlete_name VARCHAR(200) NOT NULL, goals INT DEFAULT 1, PRIMARY KEY (goal_id))"); } catch (Exception e) {}
                try { stmt.execute("CREATE TABLE ATHLETES (athlete_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), student_id VARCHAR(20) NOT NULL, full_name VARCHAR(200) NOT NULL, team_name VARCHAR(100) NOT NULL, sport_category VARCHAR(50) NOT NULL, event_category VARCHAR(50), jersey_number INT, position VARCHAR(50), PRIMARY KEY (athlete_id))"); } catch (Exception e) {}
                try { stmt.execute("DROP TABLE News"); } catch (Exception e) {}

                // Fetch teams
                try {
                    rs = stmt.executeQuery("SELECT team_name, faculty_code FROM TEAMS ORDER BY team_name");
                    while (rs.next()) {
                        teams.add(new String[]{rs.getString("team_name"), rs.getString("faculty_code")});
                    }
                    rs.close();
                } catch (Exception e) {}

                // Count matches
                try {
                    rs = stmt.executeQuery("SELECT COUNT(*) FROM FOOTBALL_MATCHES");
                    if (rs.next()) matchCount = rs.getInt(1);
                    rs.close();
                } catch (Exception e) {}

                // Fetch standings
                try {
                    rs = stmt.executeQuery("SELECT team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points FROM FOOTBALL_STANDINGS ORDER BY points DESC, goal_diff DESC, goals_for DESC");
                    while (rs.next()) {
                        standings.add(new String[]{
                            rs.getString("team_name"),
                            String.valueOf(rs.getInt("played")),
                            String.valueOf(rs.getInt("wins")),
                            String.valueOf(rs.getInt("draws")),
                            String.valueOf(rs.getInt("losses")),
                            String.valueOf(rs.getInt("goals_for")),
                            String.valueOf(rs.getInt("goals_against")),
                            String.valueOf(rs.getInt("goal_diff")),
                            String.valueOf(rs.getInt("points"))
                        });
                    }
                    rs.close();
                } catch (Exception e) {}

                // Fetch top scorers
                try {
                    rs = stmt.executeQuery("SELECT scorer_id, player_name, team_name, goals FROM FOOTBALL_TOP_SCORERS ORDER BY goals DESC");
                    while (rs.next()) {
                        tsList.add(new String[]{
                            String.valueOf(rs.getInt("scorer_id")),
                            rs.getString("player_name"),
                            rs.getString("team_name"),
                            String.valueOf(rs.getInt("goals"))
                        });
                    }
                    rs.close();
                } catch (Exception e) {}

                // Fetch registered athletes for match teams (for goalscorers)
                gsMatchId = request.getParameter("editMatchId");
                gsTeam1 = request.getParameter("emTeam1");
                gsTeam2 = request.getParameter("emTeam2");
                gsDebug = "";
                if (gsMatchId != null && gsTeam1 != null && gsTeam2 != null) {
                    athletesByMatchTeam.put(gsTeam1, new java.util.ArrayList<String[]>());
                    athletesByMatchTeam.put(gsTeam2, new java.util.ArrayList<String[]>());
                    // Build mapping: match team name → set of possible athlete team_names
                    java.util.Map<String, java.util.Set<String>> matchTeamToAthleteNames = new java.util.HashMap<String, java.util.Set<String>>();
                    matchTeamToAthleteNames.put(gsTeam1, new java.util.HashSet<String>());
                    matchTeamToAthleteNames.put(gsTeam2, new java.util.HashSet<String>());
                    matchTeamToAthleteNames.get(gsTeam1).add(gsTeam1);
                    matchTeamToAthleteNames.get(gsTeam2).add(gsTeam2);
                    try {
                        PreparedStatement fcPs = conn.prepareStatement("SELECT team_name, faculty_code FROM TEAMS WHERE team_name = ? OR team_name = ?");
                        fcPs.setString(1, gsTeam1);
                        fcPs.setString(2, gsTeam2);
                        ResultSet fcRs = fcPs.executeQuery();
                        while (fcRs.next()) {
                            String tn = fcRs.getString("team_name");
                            String fc = fcRs.getString("faculty_code");
                            for (String matchTeam : new String[]{gsTeam1, gsTeam2}) {
                                if (tn != null && tn.equals(matchTeam)) {
                                    if (tn != null) matchTeamToAthleteNames.get(matchTeam).add(tn);
                                    if (fc != null && !fc.isEmpty()) matchTeamToAthleteNames.get(matchTeam).add(fc);
                                } else if (fc != null && fc.equals(matchTeam)) {
                                    if (tn != null) matchTeamToAthleteNames.get(matchTeam).add(tn);
                                    if (fc != null && !fc.isEmpty()) matchTeamToAthleteNames.get(matchTeam).add(fc);
                                }
                            }
                        }
                        fcRs.close();
                    } catch (Exception e) { e.printStackTrace(); }
                    gsDebug = "Match1=" + gsTeam1 + " paths=" + matchTeamToAthleteNames.get(gsTeam1)
                            + " | Match2=" + gsTeam2 + " paths=" + matchTeamToAthleteNames.get(gsTeam2);
                    // Query ATHLETES for all possible team names
                    java.util.Set<String> allNames = new java.util.HashSet<String>();
                    allNames.addAll(matchTeamToAthleteNames.get(gsTeam1));
                    allNames.addAll(matchTeamToAthleteNames.get(gsTeam2));
                    try {
                        StringBuilder sql = new StringBuilder("SELECT athlete_id, full_name, team_name FROM ATHLETES WHERE team_name IN (");
                        int idx = 0;
                        for (String n : allNames) {
                            if (idx > 0) sql.append(",");
                            sql.append("?");
                            idx++;
                        }
                        sql.append(") ORDER BY team_name, full_name");
                        PreparedStatement aPs = conn.prepareStatement(sql.toString());
                        int pi = 1;
                        for (String n : allNames) {
                            aPs.setString(pi++, n);
                        }
                        ResultSet aRs = aPs.executeQuery();
                        while (aRs.next()) {
                            int aid = aRs.getInt("athlete_id");
                            String nm = aRs.getString("full_name");
                            String tm = aRs.getString("team_name");
                            // Place under the correct match team
                            for (String matchTeam : new String[]{gsTeam1, gsTeam2}) {
                                if (matchTeamToAthleteNames.get(matchTeam).contains(tm)) {
                                    athletesByMatchTeam.get(matchTeam).add(new String[]{String.valueOf(aid), nm});
                                    break;
                                }
                            }
                        }
                        aRs.close();
                    } catch (Exception e) { e.printStackTrace(); }
                    try {
                        PreparedStatement gsPs = conn.prepareStatement("SELECT athlete_id, goals FROM MATCH_GOALSCORERS WHERE match_id = ?");
                        gsPs.setInt(1, Integer.parseInt(gsMatchId.trim()));
                        ResultSet gsRs = gsPs.executeQuery();
                        while (gsRs.next()) {
                            matchGoalscorers.put(gsRs.getInt("athlete_id"), gsRs.getInt("goals"));
                        }
                        gsRs.close();
                    } catch (Exception e) { e.printStackTrace(); }
                }

            } catch (Exception e) { /* handled inline */ }
        %>

        <%
            String emTeam1 = request.getParameter("emTeam1");
            String emTeam2 = request.getParameter("emTeam2");

            // Build team options string for re-use
            StringBuilder teamOpts = new StringBuilder();
            StringBuilder team1Opts = new StringBuilder();
            StringBuilder team2Opts = new StringBuilder();
            boolean noTeamsData = false;
            java.util.List<String[]> teamSource;
            if (!teams.isEmpty()) {
                teamSource = teams;
            } else {
                String[][] fallback = {{"FSKM","FSKM"},{"FK","FK"},{"FPP","FPP"},{"FSPU","FSPU"}};
                teamSource = new java.util.ArrayList<String[]>();
                for (String[] fb : fallback) { teamSource.add(fb); }
                noTeamsData = true;
            }
            for (String[] t : teamSource) {
                String name = t[0];
                String opt = "<option value=\"" + name + "\">" + name + "</option>";
                teamOpts.append(opt);
                team1Opts.append("<option value=\"").append(name).append("\"").append(name.equals(emTeam1) ? " selected" : "").append(">").append(name).append("</option>");
                team2Opts.append("<option value=\"").append(name).append("\"").append(name.equals(emTeam2) ? " selected" : "").append(">").append(name).append("</option>");
            }
            String teamOptionsHtml = teamOpts.toString();
            String team1OptionsHtml = team1Opts.toString();
            String team2OptionsHtml = team2Opts.toString();
        %>

        <div class="row g-4">

            <%-- ========== LEFT COLUMN: Forms ========== --%>
            <%
                String editMatchId = request.getParameter("editMatchId");
                String emStage = request.getParameter("emStage");
                String emDate = request.getParameter("emDate");
                String emVenue = request.getParameter("emVenue");
                String emScore1 = request.getParameter("emScore1");
                String emScore2 = request.getParameter("emScore2");
                String emStatus = request.getParameter("emStatus");
                boolean isEditingMatch = editMatchId != null;
            %>
            <div class="col-lg-4">

                <div class="card mb-4">
                    <div class="card-header bg-white py-3">
                        <h3 class="h6 mb-0 fw-bold"><%= isEditingMatch ? "Edit Match #" + editMatchId : "Schedule New Match" %></h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="ScheduleMatchServlet">
                            <% if (isEditingMatch) { %>
                                <input type="hidden" name="matchId" value="<%= editMatchId %>">
                            <% } %>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Stage</label>
                                <input type="text" class="form-control" name="stageMeta" value="<%= emStage != null ? emStage : "" %>" required>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label small fw-bold">Date</label>
                                    <input type="text" class="form-control" name="matchDate" value="<%= emDate != null ? emDate : "" %>" required>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small fw-bold">Venue</label>
                                    <input type="text" class="form-control" name="venue" value="<%= emVenue != null ? emVenue : "" %>" required>
                                </div>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label small fw-bold">Team 1</label>
                                    <select class="form-select" name="team1Select" required>
                                        <%= team1OptionsHtml %>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small fw-bold">Team 2</label>
                                    <select class="form-select" name="team2Select" required>
                                        <%= team2OptionsHtml %>
                                    </select>
                                </div>
                            </div>
                            <% if (isEditingMatch) { %>
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label small text-muted">Score</label>
                                    <input type="number" class="form-control font-monospace" name="team1Score" min="0" placeholder="0" value="<%= emScore1 != null ? emScore1 : "" %>">
                                </div>
                                <div class="col-6">
                                    <label class="form-label small text-muted">&nbsp;</label>
                                    <input type="number" class="form-control font-monospace" name="team2Score" min="0" placeholder="0" value="<%= emScore2 != null ? emScore2 : "" %>">
                                </div>
                            </div>
                            <% } else { %>
                                <input type="hidden" name="team1Score" value="">
                                <input type="hidden" name="team2Score" value="">
                            <% } %>
                            <% if (isEditingMatch) { %>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Status</label>
                                <select class="form-select" name="statusSelect">
                                    <option value="Scheduled" <%= "Scheduled".equals(emStatus) ? "selected" : "" %>>Scheduled</option>
                                    <option value="Completed" <%= "Completed".equals(emStatus) ? "selected" : "" %>>Completed</option>
                                </select>
                            </div>
                            <% } else { %>
                                <input type="hidden" name="statusSelect" value="Scheduled">
                            <% } %>

                            <div class="card bg-light border-0 mb-3">
                                <div class="card-header bg-transparent py-2">
                                    <h4 class="h6 mb-0 fw-bold">Goalscorers</h4>
                                </div>
                                <div class="card-body py-2">
                                    <%
                                    if (gsTeam1 != null && gsTeam2 != null) {
                                        String[] matchTeams = {gsTeam1, gsTeam2};
                                        int teamIdx = 0;
                                        for (String matchTeam : matchTeams) {
                                            teamIdx++;
                                            java.util.List<String[]> teamAthletes = athletesByMatchTeam.get(matchTeam);
                                            if (teamAthletes == null) teamAthletes = new java.util.ArrayList<String[]>();
                                    %>
                                        <div class="mb-2">
                                            <span class="badge bg-dark mb-1"><%= matchTeam %></span>
                                            <% if (!teamAthletes.isEmpty()) { %>
                                            <%
                                            String preSelectedVal = "";
                                            int preSelectedGoals = 0;
                                            for (String[] athlete : teamAthletes) {
                                                int aid = Integer.parseInt(athlete[0]);
                                                Integer existingGoals = matchGoalscorers.get(aid);
                                                if (existingGoals != null && existingGoals > 0 && preSelectedVal.isEmpty()) {
                                                    preSelectedVal = athlete[0] + "|" + athlete[1];
                                                    preSelectedGoals = existingGoals;
                                                }
                                            }
                                            %>
                                            <div class="row g-1 align-items-center mb-1">
                                                <div class="col-7">
                                                    <select class="form-select form-select-sm" id="gs_player_select_<%= teamIdx %>" data-team="<%= matchTeam %>">
                                                        <option value="">-- Select --</option>
                                                        <% for (String[] athlete : teamAthletes) {
                                                            String sel = preSelectedVal.equals(athlete[0] + "|" + athlete[1]) ? "selected" : "";
                                                        %>
                                                        <option value="<%= athlete[0] %>|<%= athlete[1] %>" <%= sel %>><%= athlete[1] %></option>
                                                        <% } %>
                                                    </select>
                                                </div>
                                                <div class="col-5">
                                                    <input type="number" class="form-control form-control-sm" id="gs_goals_input_<%= teamIdx %>" min="0" value="<%= preSelectedGoals %>" placeholder="Goals">
                                                </div>
                                            </div>
                                            <% } else { %>
                                            <p class="text-muted small mb-0">No registered players yet.</p>
                                            <% } %>
                                            <div id="gs_saved_<%= teamIdx %>">
                                            <% // Hidden re-submission of previously saved scorers
                                               for (String[] athlete : teamAthletes) {
                                                   int aid = Integer.parseInt(athlete[0]);
                                                   Integer existingGoals = matchGoalscorers.get(aid);
                                                   if (existingGoals != null && existingGoals > 0) {
                                                       out.println("<input type='hidden' name='gs_team' value='" + matchTeam + "'>");
                                                       out.println("<input type='hidden' name='gs_player' value='" + athlete[0] + "'>");
                                                       out.println("<input type='hidden' name='gs_player_name' value='" + athlete[1] + "'>");
                                                       out.println("<input type='hidden' name='gs_goals' value='" + existingGoals + "'>");
                                                   }
                                               }
                                            %>
                                            </div>
                                        </div>
                                    <% }
                                    } else { %>
                                    <p class="text-muted small mb-0">Save the match first, then edit to add goalscorers.</p>
                                    <% } %>
                                    <small class="text-muted">Select a player, enter goals, then save.</small>
                                    <p class="text-muted small mb-0" style="font-size:10px;"><%= gsDebug %></p>
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-submit w-100 fw-semibold" id="scheduleBtn">
                                    <span class="btn-text"><i class="fa-solid fa-floppy-disk me-1"></i> <%= isEditingMatch ? "Update Match" : "Save Match" %></span>
                                    <span class="spinner-overlay">
                                        <span class="spinner-border spinner-border-sm"></span>
                                    </span>
                                </button>
                                <% if (isEditingMatch) { %>
                                    <a href="admin_dashboard.jsp" class="btn btn-light fw-semibold">Cancel</a>
                                <% } %>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header bg-white py-3">
                        <h3 class="h6 mb-0 fw-bold">Register Manager</h3>
                    </div>
                    <div class="card-body">
                        <form action="RegisterManagerServlet" method="POST">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Team</label>
                                <select class="form-select" name="faculty" required>
                                    <%= teamOptionsHtml %>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Full Name</label>
                                <input type="text" class="form-control" name="fullName" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Username</label>
                                <input type="text" class="form-control font-monospace" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Password</label>
                                <input type="password" class="form-control font-monospace" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 fw-semibold btn-submit" id="managerBtn">
                                <span class="btn-text"><i class="fa-solid fa-check me-1"></i> Create Account</span>
                                <span class="spinner-overlay">
                                    <span class="spinner-border spinner-border-sm"></span>
                                </span>
                            </button>
                        </form>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header bg-white py-3">
                        <h3 class="h6 mb-0 fw-bold">Add Team</h3>
                    </div>
                    <div class="card-body">
                        <form action="TeamServlet" method="POST" class="row g-3">
                            <div class="col-8">
                                <label class="form-label small fw-bold">Team Name</label>
                                <input type="text" class="form-control" name="teamName" required>
                            </div>
                            <div class="col-4">
                                <label class="form-label small fw-bold">Code</label>
                                <input type="text" class="form-control" name="facultyCode">
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-submit w-100 fw-semibold">
                                    <span class="btn-text"><i class="fa-solid fa-floppy-disk me-1"></i> Save Team</span>
                                    <span class="spinner-overlay"><span class="spinner-border spinner-border-sm"></span></span>
                                </button>
                            </div>
                        </form>
                        <hr>
                        <h6 class="small fw-bold text-muted mb-2">Registered Teams (<%= teams.size() %>)</h6>
                        <ul class="list-group list-group-flush small">
                            <% if (!teams.isEmpty()) {
                                for (String[] t : teams) { %>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-1">
                                    <span><strong><%= t[0] %></strong> <% if (t[1] != null && !t[1].isEmpty()) { %><span class="text-muted">(<%= t[1] %>)</span><% } %></span>
                                    <a href="TeamServlet?teamName=<%= java.net.URLEncoder.encode(t[0], "UTF-8") %>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete team <%= t[0] %>?')"><i class="fa-solid fa-trash-can"></i></a>
                                </li>
                            <% } } else { %>
                                <li class="list-group-item px-0 py-1 text-muted">No teams registered. Add one above.</li>
                            <% } %>
                        </ul>
                    </div>
                </div>

            </div>

            <%-- ========== RIGHT COLUMN: Tables ========== --%>
            <div class="col-lg-8">

                <%-- MATCH SCHEDULE TABLE --%>
                <div class="card mb-4">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h2 class="h5 mb-0 fw-bold">Match Schedule</h2>
                        <span class="badge bg-dark fs-6"><%= matchCount %> total</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle text-center mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Stage</th>
                                    <th>Date</th>
                                    <th>Venue</th>
                                    <th>Matchup</th>
                                    <th>Score</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <%
                                    try {
                                        if (conn != null && !conn.isClosed()) {
                                            rs = stmt.executeQuery("SELECT * FROM FOOTBALL_MATCHES ORDER BY match_id DESC");
                                            boolean hasRows = false;
                                            while (rs.next()) {
                                                hasRows = true;
                                                int mid = rs.getInt("match_id");
                                                String stg = rs.getString("stage");
                                                String t1 = rs.getString("team1");
                                                String t2 = rs.getString("team2");
                                                int s1 = rs.getInt("team1_score");
                                                int s2 = rs.getInt("team2_score");
                                                boolean nullScore = rs.wasNull();
                                                String p = rs.getString("match_date");
                                                String v = rs.getString("venue");
                                                String stP = rs.getString("status");
                                %>
                                    <tr>
                                        <td><span class="fw-bold d-block"><%= stg %></span></td>
                                        <td><%= p != null ? p : "—" %></td>
                                        <td><%= v != null ? v : "—" %></td>
                                        <td class="fw-semibold"><%= t1 %> vs <%= t2 %></td>
                                        <td><span class="font-monospace fw-bold"><%= nullScore ? "—" : (s1 + " — " + s2) %></span></td>
                                        <td>
                                            <span class="badge <%= stP.equalsIgnoreCase("Completed") ? "bg-success" : "bg-warning text-dark" %>">
                                                <%= stP %>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="?editMatchId=<%= mid %>&emStage=<%= java.net.URLEncoder.encode(stg, "UTF-8") %>&emDate=<%= java.net.URLEncoder.encode(p != null ? p : "", "UTF-8") %>&emVenue=<%= java.net.URLEncoder.encode(v != null ? v : "", "UTF-8") %>&emTeam1=<%= java.net.URLEncoder.encode(t1, "UTF-8") %>&emTeam2=<%= java.net.URLEncoder.encode(t2, "UTF-8") %>&emScore1=<%= nullScore ? "" : s1 %>&emScore2=<%= nullScore ? "" : s2 %>&emStatus=<%= java.net.URLEncoder.encode(stP, "UTF-8") %>" class="btn btn-outline-warning" title="Edit">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>
                                                <a href="DeleteMatch.jsp?id=<%= mid %>" class="btn btn-outline-danger" onclick="return confirm('Delete this match?')">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <%
                                            }
                                            rs.close();
                                            if (!hasRows) {
                                %>
                                    <tr><td colspan="7" class="text-muted py-4">No matches scheduled yet.</td></tr>
                                <%
                                            }
                                        }
                                    } catch (Exception e) {
                                %>
                                    <tr><td colspan="7" class="text-danger py-3"><i class="fa-solid fa-triangle-exclamation me-1"></i> <%= e.getMessage() %></td></tr>
                                <%
                                    }
                                %>
                            </tbody>
                        </table>
                    </div>
                </div>

                <%-- LEAGUE TABLE --%>
                <div class="card mb-4">
                    <div class="card-header bg-white py-3">
                        <h2 class="h5 mb-0 fw-bold">Football League Table</h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 text-center">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 5%">#</th>
                                    <th class="text-start" style="width: 25%">Team</th>
                                    <th>P</th><th>W</th><th>D</th><th>L</th>
                                    <th>GF</th><th>GA</th><th>GD</th>
                                    <th class="fw-bold">PTS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <%
                                    if (!standings.isEmpty()) {
                                        int rank = 0;
                                        for (String[] s : standings) {
                                            rank++;
                                %>
                                    <tr>
                                        <td><span class="badge bg-dark text-white fw-bold px-2"><%= rank %></span></td>
                                        <td class="text-start fw-bold"><%= s[0] %></td>
                                        <td><%= s[1] %></td><td><%= s[2] %></td><td><%= s[3] %></td><td><%= s[4] %></td>
                                        <td><%= s[5] %></td><td><%= s[6] %></td>
                                        <td class="fw-bold"><%= s[7] %></td>
                                        <td class="fw-bold text-primary"><%= s[8] %></td>
                                    </tr>
                                <%
                                        }
                                    } else if (!teams.isEmpty()) {
                                        // Teams exist but no standings data yet — show zeros
                                        int rank = 0;
                                        for (String[] t : teams) {
                                            rank++;
                                %>
                                    <tr>
                                        <td><span class="badge bg-dark text-white fw-bold px-2"><%= rank %></span></td>
                                        <td class="text-start fw-bold"><%= t[0] %></td>
                                        <td>0</td><td>0</td><td>0</td><td>0</td>
                                        <td>0</td><td>0</td>
                                        <td class="text-muted">0</td>
                                        <td class="fw-bold text-primary">0</td>
                                    </tr>
                                <%
                                        }
                                    } else {
                                %>
                                    <tr>
                                        <td colspan="10" class="text-muted py-4">No league data yet. Add teams and complete some matches to auto-populate.</td>
                                    </tr>
                                <% } %>
                            </tbody>
                        </table>
                    </div>
                </div>



                <%-- ========== TOP SCORERS ========== --%>
                <div class="card mb-4">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h2 class="h5 mb-0 fw-bold">Top Scorers</h2>
                        <span class="badge bg-dark fs-6"><%= tsList.size() %></span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle text-center mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 8%">Rank</th>
                                    <th class="text-start">Player</th>
                                    <th>Team</th>
                                    <th>G</th>
                                </tr>
                            </thead>
                            <tbody>
                                <%
                                    if (!tsList.isEmpty()) {
                                        int rank = 0;
                                        for (String[] sc : tsList) {
                                            rank++;
                                %>
                                    <tr>
                                        <td class="fw-bold"><%= rank %></td>
                                        <td class="text-start fw-bold"><%= sc[1] %></td>
                                        <td><%= sc[2] %></td>
                                        <td class="fw-bold"><%= sc[3] %></td>
                                    </tr>
                                <%
                                        }
                                    } else {
                                %>
                                    <tr>
                                        <td colspan="4" class="text-muted py-3">No top scorers recorded yet.</td>
                                    </tr>
                                <% } %>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>

    </main>
    <footer class="bg-dark text-white text-center py-3 mt-4 small">
        &copy; 2026 Liga-Kampus Football League Operations &mdash;
        <a href="index.jsp" class="text-white-50 text-decoration-none">Home</a>
    </footer>

    <script>
        document.querySelectorAll('form').forEach(function (form) {
            form.addEventListener('submit', function () {
                // Collect each team's dropdown selection
                var idx = 1;
                while (true) {
                    var select = document.getElementById('gs_player_select_' + idx);
                    if (!select) break;
                    var goalsInput = document.getElementById('gs_goals_input_' + idx);
                    var val = select.value;
                    if (val) {
                        var parts = val.split('|');
                        var playerId = parts[0];
                        var playerName = parts[1];
                        var goals = parseInt(goalsInput.value) || 0;
                        var teamName = select.getAttribute('data-team');
                        var container = document.getElementById('gs_saved_' + idx);
                        // Remove any existing hidden inputs for this player
                        var allPlayers = container.querySelectorAll('input[type=hidden][name=gs_player]');
                        for (var i = 0; i < allPlayers.length; i++) {
                            if (allPlayers[i].value === playerId) {
                                var pInput = allPlayers[i];
                                var prev = pInput.previousElementSibling;
                                var next1 = pInput.nextElementSibling;
                                var next2 = next1 ? next1.nextElementSibling : null;
                                if (prev && prev.name === 'gs_team') prev.remove();
                                pInput.remove();
                                if (next1 && next1.name === 'gs_player_name') next1.remove();
                                if (next2 && next2.name === 'gs_goals') next2.remove();
                                break;
                            }
                        }
                        // Add new entry if goals > 0
                        if (goals > 0) {
                            var ht = document.createElement('input');
                            ht.type = 'hidden'; ht.name = 'gs_team'; ht.value = teamName;
                            var hp = document.createElement('input');
                            hp.type = 'hidden'; hp.name = 'gs_player'; hp.value = playerId;
                            var hpn = document.createElement('input');
                            hpn.type = 'hidden'; hpn.name = 'gs_player_name'; hpn.value = playerName;
                            var hg = document.createElement('input');
                            hg.type = 'hidden'; hg.name = 'gs_goals'; hg.value = goals;
                            container.appendChild(ht);
                            container.appendChild(hp);
                            container.appendChild(hpn);
                            container.appendChild(hg);
                        }
                    }
                    idx++;
                }
                var btn = this.querySelector('.btn-submit');
                if (btn) {
                    btn.classList.add('loading');
                    btn.style.pointerEvents = 'none';
                }
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
