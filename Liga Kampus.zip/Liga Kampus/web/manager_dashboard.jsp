<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, java.util.List" %>
<%
    if (session.getAttribute("user") == null || !"Manager".equals(session.getAttribute("role"))) {
        response.sendRedirect("as_login.jsp");
        return;
    }
    String faculty = (String) session.getAttribute("faculty");
    if (faculty == null) faculty = "";
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Football League | Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .btn-danger, .btn-danger:hover, .btn-danger:active, .btn-danger:focus { background: #dc3545; border-color: #dc3545; box-shadow: none; }
        .btn-charcoal, .btn-charcoal:hover, .btn-charcoal:active, .btn-charcoal:focus { background: #2d2d2d; border-color: #2d2d2d; color: white; box-shadow: none; }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark" style="background: purple;">
        <div class="container">
            <a class="navbar-brand" href="index.jsp"><img src="img/logo.png" alt="UiTM Football League" height="60"></a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto"></ul>
                <div class="navbar-nav align-items-center gap-2">
                    <span class="nav-link text-light">
                        <%= session.getAttribute("fullName") %>
                        <span class="badge bg-light text-dark ms-1"><%= session.getAttribute("role") %></span>
                        <span class="badge bg-info text-dark ms-1"><%= faculty %></span>
                    </span>
                    <a href="logout.jsp" class="btn btn-sm btn-danger fw-bold">Log Out</a>
                </div>
            </div>
        </div>
    </nav>

    <header class="bg-white border-bottom py-4 mb-4 shadow-sm">
        <div class="container">
            <span class="text-uppercase tracking-wider small fw-bold text-primary"><%= faculty %></span>
            <h1 class="h3 fw-bold mb-1">Athlete Management</h1>
            <p class="text-muted mb-0">Register athletes under your faculty. Squad limit: 14 per sport.</p>
        </div>
    </header>

    <main class="container my-4">

        <%-- Status alerts --%>
        <%
            String status = request.getParameter("status");
            if (status != null) {
                if ("athlete_saved".equals(status)) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Athlete saved.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if ("athlete_deleted".equals(status)) {
        %>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i>
                <strong>Success!</strong> Athlete removed from roster.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if ("db_error".equals(status)) {
        %>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-circle-xmark me-1"></i>
                <strong>Database Error!</strong> The operation could not be completed.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                } else if ("invalid_input".equals(status) || "driver_error".equals(status)) {
        %>
            <div class="alert alert-warning alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-1"></i>
                <strong>System Error!</strong> Invalid input or configuration issue.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <%
                }
            }
        %>

        <%-- DB connection + data fetch --%>
        <%
            String dbUrl = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
            String dbUser = "ligakampusDB";
            String dbPass = "ligakampus123";
            Connection conn = null;
            Statement stmt = null;
            ResultSet rs = null;
            java.util.List<String[]> athletes = new java.util.ArrayList<String[]>();
            int athleteCount = 0;

            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
                stmt = conn.createStatement();

                try { stmt.execute("CREATE TABLE ATHLETES (athlete_id INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), student_id VARCHAR(20) NOT NULL, full_name VARCHAR(200) NOT NULL, team_name VARCHAR(100) NOT NULL, sport_category VARCHAR(50) NOT NULL, event_category VARCHAR(50), jersey_number INT, position VARCHAR(50), PRIMARY KEY (athlete_id))"); } catch (Exception e) {}

                try {
                    PreparedStatement ps = conn.prepareStatement("SELECT athlete_id, student_id, full_name, sport_category, event_category, jersey_number, position FROM ATHLETES WHERE team_name = ? ORDER BY full_name");
                    ps.setString(1, faculty);
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        athletes.add(new String[]{
                            String.valueOf(rs.getInt("athlete_id")),
                            rs.getString("student_id"),
                            rs.getString("full_name"),
                            rs.getString("sport_category"),
                            rs.getString("event_category"),
                            rs.getString("jersey_number") != null ? String.valueOf(rs.getInt("jersey_number")) : "",
                            rs.getString("position") != null ? rs.getString("position") : ""
                        });
                    }
                    rs.close();
                    athleteCount = athletes.size();
                } catch (Exception e) {}

            } catch (Exception e) { /* handled inline */ }
        %>

        <%
            String editAthlete = request.getParameter("editAthlete");
            String eStudentId = request.getParameter("eStudentId");
            String eFullName = request.getParameter("eFullName");
            String eSportCat = request.getParameter("eSportCat");
            String eEventCat = request.getParameter("eEventCat");
            String eJersey = request.getParameter("eJersey");
            String ePosition = request.getParameter("ePosition");
            boolean isEditing = (editAthlete != null);
        %>

        <div class="row g-4">

            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4" id="registrationFormCard">
                    <div class="card-header bg-primary text-white py-3">
                        <h2 class="h6 mb-0 fw-bold"><%= isEditing ? "Edit Athlete" : "Register New Athlete" %></h2>
                    </div>
                    <div class="card-body">
                        <form action="AthleteServlet" method="POST">
                            <% if (isEditing) { %>
                                <input type="hidden" name="athleteId" value="<%= editAthlete %>">
                            <% } %>
                            <input type="hidden" name="teamName" value="<%= faculty %>">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Student ID</label>
                                <input type="text" class="form-control" name="studentId" value="<%= isEditing ? eStudentId : "" %>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Full Name</label>
                                <input type="text" class="form-control" name="fullName" value="<%= isEditing ? eFullName : "" %>" required>
                            </div>

                            <div class="row g-2 mb-4">
                                <div class="col-4">
                                    <label class="form-label small fw-bold">Jersey #</label>
                                    <input type="number" class="form-control" name="jerseyNum" min="1" max="99" value="<%= isEditing ? eJersey : "" %>">
                                </div>
                                <div class="col-8">
                                    <label class="form-label small fw-bold">Position</label>
                                    <input type="text" class="form-control" name="position" value="<%= isEditing ? ePosition : "" %>">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-charcoal w-100 fw-semibold mb-2">
                                <%= isEditing ? "Update Athlete" : "Save Registration" %>
                            </button>
                            <% if (isEditing) { %>
                                <a href="manager_dashboard.jsp" class="btn btn-light border w-100 fw-semibold">
                                    Cancel Edit
                                </a>
                            <% } %>
                        </form>
                    </div>
                </div>

                <div class="card border-0 shadow-sm text-dark bg-white">
                    <div class="card-body">
                        <h3 class="h6 fw-bold border-bottom pb-2 mb-3">Roster Limitations</h3>

                        <div class="d-flex justify-content-between mb-2 small">
                            <span>Football Squad:</span>
                            <span class="<%= athleteCount >= 14 ? "text-danger" : "text-success" %> fw-bold" id="footballCountLabel">
                                <%= athleteCount %> / 14 <%= athleteCount >= 14 ? "(FULL)" : "" %>
                            </span>
                        </div>
                        <div class="progress mb-3" style="height: 6px;">
                            <div class="<%= athleteCount >= 14 ? "bg-danger" : "bg-success" %>" role="progressbar" id="footballProgress" style="width: <%= Math.min(athleteCount * 100 / 14, 100) %>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card border-0 shadow-sm p-4 bg-white">
                    <ul class="nav nav-tabs mb-4" id="rosterTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="fb-tab" data-bs-toggle="tab" data-bs-target="#fb-pane" type="button" role="tab">
                                Football <span class="badge <%= athleteCount >= 14 ? "bg-danger" : "bg-secondary" %>"><%= athleteCount %></span>
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content" id="rosterTabContent">
                        <div class="tab-pane fade show active" id="fb-pane" role="tabpanel">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Athlete Name</th>
                                            <th>Event Details</th>
                                            <th>Jersey / Position</th>
                                            <th class="text-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <%
                                            if (!athletes.isEmpty()) {
                                                for (String[] a : athletes) {
                                        %>
                                            <tr>
                                                <td>
                                                    <span class="fw-bold d-block"><%= a[2] %></span>
                                                    <small class="text-muted font-monospace">ID: <%= a[1] %></small>
                                                </td>
                                                <td><span class="badge bg-dark"><%= a[4] %></span></td>
                                                <td><%= !a[5].isEmpty() ? "#" + a[5] : "" %><%= !a[5].isEmpty() && !a[6].isEmpty() ? " (" : "" %><%= a[6] %><%= !a[5].isEmpty() && !a[6].isEmpty() ? ")" : "" %><%= a[5].isEmpty() && a[6].isEmpty() ? "—" : "" %></td>
                                                <td class="text-center">
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="?editAthlete=<%= a[0] %>&eStudentId=<%= java.net.URLEncoder.encode(a[1], "UTF-8") %>&eFullName=<%= java.net.URLEncoder.encode(a[2], "UTF-8") %>&eSportCat=Football&eEventCat=Football+Open&eJersey=<%= a[5] %>&ePosition=<%= java.net.URLEncoder.encode(a[6], "UTF-8") %>" class="btn btn-outline-secondary" title="Edit">
                                                            <i class="fa-solid fa-user-pen"></i>
                                                        </a>
                                                        <a href="AthleteServlet?delete=<%= a[0] %>" class="btn btn-outline-danger" onclick="return confirm('Remove <%= a[2] %> from roster?')" title="Delete">
                                                            <i class="fa-solid fa-user-xmark"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <%
                                                }
                                            } else {
                                        %>
                                            <tr>
                                                <td colspan="4" class="text-muted py-4 text-center">No athletes registered yet. Add one above.</td>
                                            </tr>
                                        <%
                                            }
                                        %>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-5 small">
        &copy; UiTM Football League — Faculty Manager Portal
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
