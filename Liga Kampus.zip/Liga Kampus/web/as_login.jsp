<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Football League | Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #2d2d2d;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            border: none;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.97);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .login-header {
            background: #6a0dad;
            color: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        .btn-submit {
            background: #6a0dad;
            border: none;
        }
        .btn-submit:hover,
        .btn-submit:active,
        .btn-submit:focus {
            background: #6a0dad;
            border: none;
            box-shadow: none;
        }
        input[type="password"]::-ms-reveal,
        input[type="password"]::-ms-clear {
            display: none;
        }
        input[type="password"]::-webkit-text-security {
            display: none;
        }
        input[type="password"]::-webkit-credentials-auto-fill-button {
            display: none !important;
        }
        .btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        .spinner-overlay {
            display: none;
            position: absolute;
            inset: 0;
            align-items: center;
            justify-content: center;
            background: inherit;
            border-radius: inherit;
        }
        .btn-submit.loading .spinner-overlay {
            display: flex;
        }
        .btn-submit.loading .btn-text {
            visibility: hidden;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">

                <div class="card login-card shadow-lg">

                    <div class="login-header p-4 text-center">
                        <h1 class="h4 fw-bold mb-1">UiTM Football League</h1>
                        <p class="small mb-0 opacity-75">Admin & Manager Access</p>
                    </div>

                    <div class="card-body p-4">



                        <form id="authForm" action="AdminLoginServlet" method="POST" class="needs-validation" novalidate>

                            <c:if test="${not empty requestScope.errorMessage}">
                                <div class="alert alert-danger py-2 px-3 small mb-3 text-center" role="alert">
                                    <i class="fa-solid fa-triangle-exclamation me-1"></i> <c:out value="${requestScope.errorMessage}"/>
                                </div>
                            </c:if>

                            <div class="mb-3">
                                <label for="usernameInput" class="form-label small fw-bold">Username</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-user"></i></span>
                                    <input type="text" class="form-control font-monospace" id="usernameInput" name="username" required placeholder="Enter Username" autofocus value="<c:out value='${param.username}'/>">
                                    <div class="invalid-feedback">Username is required.</div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="passwordInput" class="form-label small fw-bold">Password</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control font-monospace" id="passwordInput" name="password" required>

                                    <div class="invalid-feedback">Password is required.</div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-submit w-100 fw-semibold mb-3 py-2 shadow-sm" id="submitBtn">
                                <span class="btn-text"><i class="fa-solid fa-right-to-bracket me-1"></i> Enter</span>
                                <span class="spinner-overlay">
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    <span class="visually-hidden">Loading...</span>
                                </span>
                            </button>

                            <div class="d-flex justify-content-between">
                                <a href="index.jsp" class="text-decoration-none small text-muted">
                                    <i class="fa-solid fa-arrow-left me-1"></i> Home
                                </a>
                            </div>

                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <script>
        const form      = document.getElementById('authForm');
        const submitBtn = document.getElementById('submitBtn');
        // Form submission behavior updates for standard POST handling
        form.addEventListener('submit', function (e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
                form.classList.add('was-validated');
            } else {
                submitBtn.classList.add('loading');
                submitBtn.style.pointerEvents = 'none';
            }
        });

    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>