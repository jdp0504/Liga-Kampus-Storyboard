<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    String idStr = request.getParameter("id");

    if (idStr != null && !idStr.trim().isEmpty()) {
        String dbUrl = "jdbc:derby://localhost:1527/ligakampusDB;create=true";
        String dbUser = "ligakampusDB";
        String dbPass = "ligakampus123";

        Connection conn = null;
        PreparedStatement ps = null;
        Statement stmt = null;
        ResultSet teamsRs = null;
        PreparedStatement matchPs = null;
        ResultSet matchRs = null;
        PreparedStatement gsPs = null;
        ResultSet gsRs = null;
        PreparedStatement upsertPs = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);

            ps = conn.prepareStatement("DELETE FROM FOOTBALL_MATCHES WHERE match_id = ?");
            ps.setInt(1, Integer.parseInt(idStr.trim()));
            ps.executeUpdate();

            // Recalculate standings after deletion
            stmt = conn.createStatement();
            stmt.execute("DELETE FROM FOOTBALL_STANDINGS");
            teamsRs = stmt.executeQuery("SELECT team_name FROM TEAMS");
            while (teamsRs.next()) {
                String team = teamsRs.getString("team_name");
                int played = 0, wins = 0, draws = 0, losses = 0;
                int gf = 0, ga = 0;

                matchPs = conn.prepareStatement(
                        "SELECT match_id, team1_score, team2_score, team1, team2 FROM FOOTBALL_MATCHES WHERE status = 'Completed' AND (team1 = ? OR team2 = ?) AND team1_score IS NOT NULL AND team2_score IS NOT NULL");
                matchPs.setString(1, team);
                matchPs.setString(2, team);
                matchRs = matchPs.executeQuery();
                while (matchRs.next()) {
                    int matchId = matchRs.getInt("match_id");
                    int s1 = matchRs.getInt("team1_score");
                    int s2 = matchRs.getInt("team2_score");
                    String t1 = matchRs.getString("team1");
                    String t2 = matchRs.getString("team2");
                    played++;
                    // goals_against from match score (opponent's goals)
                    if (t1.equals(team)) {
                        ga += s2;
                        if (s1 > s2) wins++;
                        else if (s1 < s2) losses++;
                        else draws++;
                    } else {
                        ga += s1;
                        if (s2 > s1) wins++;
                        else if (s2 < s1) losses++;
                        else draws++;
                    }
                    // goals_for from MATCH_GOALSCORERS (actual player goals)
                    gsPs = conn.prepareStatement(
                            "SELECT COALESCE(SUM(goals), 0) FROM MATCH_GOALSCORERS WHERE match_id = ? AND team_name = ?");
                    gsPs.setInt(1, matchId);
                    gsPs.setString(2, team);
                    gsRs = gsPs.executeQuery();
                    if (gsRs.next()) {
                        gf += gsRs.getInt(1);
                    }
                }

                int gd = gf - ga;
                int points = wins * 3 + draws;
                upsertPs = conn.prepareStatement(
                        "INSERT INTO FOOTBALL_STANDINGS (team_name, played, wins, draws, losses, goals_for, goals_against, goal_diff, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                upsertPs.setString(1, team);
                upsertPs.setInt(2, played);
                upsertPs.setInt(3, wins);
                upsertPs.setInt(4, draws);
                upsertPs.setInt(5, losses);
                upsertPs.setInt(6, gf);
                upsertPs.setInt(7, ga);
                upsertPs.setInt(8, gd);
                upsertPs.setInt(9, points);
                upsertPs.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (gsRs != null) gsRs.close(); } catch (Exception e) {}
            try { if (gsPs != null) gsPs.close(); } catch (Exception e) {}
            try { if (matchRs != null) matchRs.close(); } catch (Exception e) {}
            try { if (matchPs != null) matchPs.close(); } catch (Exception e) {}
            try { if (teamsRs != null) teamsRs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (upsertPs != null) upsertPs.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
    response.sendRedirect("admin_dashboard.jsp");
%>
